export type KafkaMessageStatus = "pending" | "consumed";

export interface KafkaHeader {
  key: string;
  value: string;
}

export interface KafkaConsumerRecord {
  groupId: string;
  consumedAt: string;
  memberId?: string;
}

export interface KafkaMessage {
  id: string;
  topic: string;
  partition: number;
  offset: number;
  timestamp: string;
  key: string | null;
  payload: unknown;
  producer?: string;
  headers?: KafkaHeader[];
  consumerGroups?: KafkaConsumerRecord[];
  status?: KafkaMessageStatus;
}

export interface KafkaProducedEvent {
  eventId: string;
  type: "produced";
  message: KafkaMessage;
}

export type KafkaConsumedEvent = {
  eventId: string;
  type: "consumed";
  consumerGroup: string;
  timestamp?: string;
  memberId?: string;
} & (
  | {
      messageId: string;
      topic?: string;
      partition?: number;
      offset?: number;
    }
  | {
      messageId?: never;
      topic: string;
      partition: number;
      offset: number;
    }
);

export type KafkaLogEvent = KafkaProducedEvent | KafkaConsumedEvent;

export interface KafkaLiveLogsProps {
  /** Seed rows shown when the component mounts or this array changes. */
  initialMessages?: KafkaMessage[];
  /** Append-only producer/consumer events from a future Kafka adapter. */
  events?: readonly KafkaLogEvent[];
  /** Turn on the local producer/consumer simulator; never required in an integrated app. */
  demoMode?: boolean;
  /** Maximum number of newest messages retained in client state. */
  maxMessages?: number;
  className?: string;
  onClear?: () => void;
  onLiveChange?: (isLive: boolean) => void;
  onEventReceived?: (event: KafkaLogEvent) => void;
  onMessageSelect?: (message: KafkaMessage) => void;
}
