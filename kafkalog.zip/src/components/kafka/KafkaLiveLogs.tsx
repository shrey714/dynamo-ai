import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import {
  Activity,
  ArrowDownToLine,
  Check,
  ChevronDown,
  ChevronRight,
  CircleDot,
  Clock3,
  Filter,
  Layers3,
  Pause,
  Play,
  Radio,
  Search,
  Trash2,
  Users,
  Waves,
  X,
} from "lucide-react";
import "./kafka-live-logs.css";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  ScrollArea,
  ScrollBar,
} from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { DEMO_CONSUMER_GROUPS, LIVE_TEMPLATES } from "./sample-data";
import type {
  KafkaConsumedEvent,
  KafkaLiveLogsProps,
  KafkaLogEvent,
  KafkaMessage,
  KafkaProducedEvent,
} from "./types";

const ALL_FILTER = "__all__";
const DEFAULT_MAX_MESSAGES = 250;
const ARRIVAL_SPACE_MS = 900;
const ARRIVAL_DWELL_MS = 120;
const useIsomorphicLayoutEffect =
  typeof window === "undefined" ? useEffect : useLayoutEffect;

type StatusFilter = "all" | "consumed" | "pending";

function matchesMessageFilters(
  message: KafkaMessage,
  search: string,
  topicFilter: string,
  groupFilter: string,
  statusFilter: StatusFilter,
) {
  const groups = message.consumerGroups ?? [];
  const status = messageStatus(message);
  if (topicFilter !== ALL_FILTER && message.topic !== topicFilter) return false;
  if (groupFilter !== ALL_FILTER && !groups.some((record) => record.groupId === groupFilter)) {
    return false;
  }
  if (statusFilter !== "all" && status !== statusFilter) return false;
  if (!search) return true;

  const searchable = [
    message.id,
    message.topic,
    message.partition,
    message.offset,
    message.key ?? "",
    message.producer ?? "",
    groups.map((record) => record.groupId).join(" "),
    serialize(message.payload),
  ]
    .join(" ")
    .toLowerCase();
  return searchable.includes(search);
}

function byNewest(messages: KafkaMessage[]) {
  return [...messages].sort(
    (left, right) =>
      new Date(right.timestamp).getTime() - new Date(left.timestamp).getTime(),
  );
}

function messageStatus(message: KafkaMessage): "consumed" | "pending" {
  return message.consumerGroups?.length || message.status === "consumed"
    ? "consumed"
    : "pending";
}

function serialize(value: unknown) {
  try {
    const json = JSON.stringify(value, null, 2);
    return json === undefined ? String(value) : json;
  } catch {
    return String(value);
  }
}

function preview(value: unknown) {
  const compact = serialize(value).replace(/\s+/g, " ");
  return compact.length > 78 ? `${compact.slice(0, 75)}…` : compact;
}

function timeLabel(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return { short: value, full: value };
  return {
    short: new Intl.DateTimeFormat(undefined, {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    }).format(date),
    full: new Intl.DateTimeFormat(undefined, {
      dateStyle: "medium",
      timeStyle: "medium",
    }).format(date),
  };
}

function eventMatchesMessage(event: KafkaConsumedEvent, message: KafkaMessage) {
  if (event.messageId) return message.id === event.messageId;
  return (
    message.topic === event.topic &&
    message.partition === event.partition &&
    message.offset === event.offset
  );
}

function applyEvent(
  current: KafkaMessage[],
  event: KafkaLogEvent,
  maxMessages: number,
): KafkaMessage[] {
  if (event.type === "produced") {
    const message: KafkaMessage = {
      ...event.message,
      consumerGroups: [...(event.message.consumerGroups ?? [])],
    };
    return [message, ...current.filter((item) => item.id !== message.id)].slice(
      0,
      maxMessages,
    );
  }

  return current.map((message) => {
    if (!eventMatchesMessage(event, message)) return message;
    const records = message.consumerGroups ?? [];
    const existing = records.findIndex(
      (record) => record.groupId === event.consumerGroup,
    );
    const consumerRecord = {
      groupId: event.consumerGroup,
      consumedAt: event.timestamp ?? new Date().toISOString(),
      ...(event.memberId ? { memberId: event.memberId } : {}),
    };
    const consumerGroups =
      existing === -1
        ? [...records, consumerRecord]
        : records.map((record, index) =>
            index === existing ? { ...record, ...consumerRecord } : record,
          );
    return { ...message, consumerGroups, status: "consumed" };
  });
}

function Metric({
  label,
  value,
  icon: Icon,
  tone,
}: {
  label: string;
  value: string | number;
  icon: typeof Activity;
  tone: "blue" | "green" | "amber" | "neutral";
}) {
  return (
    <div className="kafka-metric">
      <span className={`kafka-metric-icon kafka-tone-${tone}`}>
        <Icon aria-hidden="true" className="size-4" />
      </span>
      <span className="min-w-0">
        <span className="kafka-metric-value">{value}</span>
        <span className="kafka-metric-label">{label}</span>
      </span>
    </div>
  );
}

function KafkaLiveLogs({
  initialMessages = [],
  events,
  demoMode = false,
  maxMessages = DEFAULT_MAX_MESSAGES,
  className,
  onClear,
  onLiveChange,
  onEventReceived,
  onMessageSelect,
}: KafkaLiveLogsProps) {
  const [messages, setMessages] = useState<KafkaMessage[]>(() =>
    byNewest(initialMessages).slice(0, Math.max(1, maxMessages)),
  );
  const [isLive, setIsLive] = useState(true);
  const [queuedCount, setQueuedCount] = useState(0);
  const [query, setQuery] = useState("");
  const [topicFilter, setTopicFilter] = useState(ALL_FILTER);
  const [groupFilter, setGroupFilter] = useState(ALL_FILTER);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [expandedIds, setExpandedIds] = useState<Set<string>>(() => new Set());
  const [newMessageIds, setNewMessageIds] = useState<Set<string>>(() => new Set());
  const [activeArrival, setActiveArrival] = useState<KafkaProducedEvent | null>(null);
  const rootRef = useRef<HTMLElement | null>(null);
  const previousRowPositionsRef = useRef<Map<string, number> | null>(null);
  const isLiveRef = useRef(isLive);
  const pendingEventsRef = useRef<KafkaLogEvent[]>([]);
  const liveEventQueueRef = useRef<KafkaLogEvent[]>([]);
  const activeArrivalRef = useRef<KafkaProducedEvent | null>(null);
  const arrivalTimerRef = useRef<number | null>(null);
  const nextArrivalTimerRef = useRef<number | null>(null);
  const processNextLiveEventRef = useRef<() => void>(() => {});
  const seenEventIdsRef = useRef(new Set<string>());
  const entranceTimersRef = useRef(new Map<string, number>());
  const onEventReceivedRef = useRef(onEventReceived);
  const demoSequenceRef = useRef(0);
  const safeLimit = Math.max(1, Math.floor(maxMessages));

  const captureRowPositions = useCallback(() => {
    const root = rootRef.current;
    if (!root) return;
    const positions = new Map<string, number>();
    root.querySelectorAll<HTMLTableRowElement>("tr[data-kafka-message-id]").forEach((row) => {
      const id = row.dataset.kafkaMessageId;
      if (id) positions.set(id, row.getBoundingClientRect().top);
    });
    previousRowPositionsRef.current = positions;
  }, []);

  useEffect(() => {
    setMessages(byNewest(initialMessages).slice(0, safeLimit));
  }, [initialMessages, safeLimit]);

  useEffect(() => {
    isLiveRef.current = isLive;
  }, [isLive]);

  useEffect(() => {
    onEventReceivedRef.current = onEventReceived;
  }, [onEventReceived]);

  useIsomorphicLayoutEffect(() => {
    const previousPositions = previousRowPositionsRef.current;
    if (!previousPositions) return;
    previousRowPositionsRef.current = null;
    if (!activeArrival) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const root = rootRef.current;
    if (!root) return;
    const viewport = root.querySelector<HTMLElement>(
      ".kafka-table-scroll [data-slot='scroll-area-viewport']",
    );
    const viewportBounds = viewport?.getBoundingClientRect();
    root.querySelectorAll<HTMLTableRowElement>("tr[data-kafka-message-id]").forEach((row) => {
      const id = row.dataset.kafkaMessageId;
      if (!id) return;
      const previousTop = previousPositions.get(id);
      if (previousTop === undefined) return;

      const bounds = row.getBoundingClientRect();
      if (
        viewportBounds &&
        (bounds.bottom <= viewportBounds.top || bounds.top >= viewportBounds.bottom)
      ) {
        return;
      }

      const offset = previousTop - bounds.top;
      if (Math.abs(offset) < 1) return;
      Array.from(row.cells).forEach((cell, index) => {
        if (typeof cell.animate !== "function") return;
        cell.animate(
          [{ transform: `translateY(${offset}px)` }, { transform: "translateY(0px)" }],
          {
            duration: 760,
            delay: index * 18,
            easing: "cubic-bezier(0.22, 1, 0.36, 1)",
          },
        );
      });
    });
  }, [activeArrival]);

  const removeNewMessage = useCallback((messageId: string) => {
    const timer = entranceTimersRef.current.get(messageId);
    if (timer !== undefined) window.clearTimeout(timer);
    entranceTimersRef.current.delete(messageId);
    setNewMessageIds((current) => {
      if (!current.has(messageId)) return current;
      const next = new Set(current);
      next.delete(messageId);
      return next;
    });
  }, []);

  const markNewMessage = useCallback((messageId: string) => {
    setNewMessageIds((current) => new Set(current).add(messageId));
    const previousTimer = entranceTimersRef.current.get(messageId);
    if (previousTimer !== undefined) window.clearTimeout(previousTimer);
    const timer = window.setTimeout(() => removeNewMessage(messageId), 1_450);
    entranceTimersRef.current.set(messageId, timer);
  }, [removeNewMessage]);

  useEffect(() => () => {
    entranceTimersRef.current.forEach((timer) => window.clearTimeout(timer));
    entranceTimersRef.current.clear();
    if (arrivalTimerRef.current !== null) window.clearTimeout(arrivalTimerRef.current);
    if (nextArrivalTimerRef.current !== null) window.clearTimeout(nextArrivalTimerRef.current);
    liveEventQueueRef.current = [];
    pendingEventsRef.current = [];
  }, []);

  const processNextLiveEvent = useCallback(() => {
    if (
      !isLiveRef.current ||
      activeArrivalRef.current ||
      nextArrivalTimerRef.current !== null
    ) {
      return;
    }

    while (liveEventQueueRef.current.length > 0) {
      const event = liveEventQueueRef.current.shift()!;
      if (event.type === "consumed") {
        setMessages((current) => applyEvent(current, event, safeLimit));
        continue;
      }

      const visibleInCurrentView = matchesMessageFilters(
        event.message,
        query.trim().toLowerCase(),
        topicFilter,
        groupFilter,
        statusFilter,
      );
      const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (!visibleInCurrentView || reducedMotion) {
        setMessages((current) => applyEvent(current, event, safeLimit));
        continue;
      }

      captureRowPositions();
      activeArrivalRef.current = event;
      setActiveArrival(event);
      arrivalTimerRef.current = window.setTimeout(() => {
        arrivalTimerRef.current = null;
        markNewMessage(event.message.id);
        setMessages((current) => applyEvent(current, event, safeLimit));
        activeArrivalRef.current = null;
        setActiveArrival(null);
        nextArrivalTimerRef.current = window.setTimeout(() => {
          nextArrivalTimerRef.current = null;
          processNextLiveEventRef.current();
        }, ARRIVAL_DWELL_MS);
      }, ARRIVAL_SPACE_MS);
      return;
    }
  }, [captureRowPositions, groupFilter, markNewMessage, query, safeLimit, statusFilter, topicFilter]);

  processNextLiveEventRef.current = processNextLiveEvent;

  const enqueueLiveEvent = useCallback((event: KafkaLogEvent) => {
    liveEventQueueRef.current.push(event);
    processNextLiveEventRef.current();
  }, []);

  const receiveEvent = useCallback((incoming: KafkaLogEvent) => {
    if (seenEventIdsRef.current.has(incoming.eventId)) return;
    seenEventIdsRef.current.add(incoming.eventId);
    const event: KafkaLogEvent =
      incoming.type === "consumed" && !incoming.timestamp
        ? { ...incoming, timestamp: new Date().toISOString() }
        : incoming;
    onEventReceivedRef.current?.(event);

    if (!isLiveRef.current) {
      pendingEventsRef.current.push(event);
      setQueuedCount(pendingEventsRef.current.length);
      return;
    }

    enqueueLiveEvent(event);
  }, [enqueueLiveEvent]);

  useEffect(() => {
    if (!events) return;
    events.forEach(receiveEvent);
  }, [events, receiveEvent]);

  useEffect(() => {
    if (!demoMode) return;
    const timer = window.setInterval(() => {
      const sequence = demoSequenceRef.current++;
      const template = LIVE_TEMPLATES[sequence % LIVE_TEMPLATES.length];
      const id = `demo-live-${sequence}`;
      const now = new Date().toISOString();
      const message: KafkaMessage = {
        id,
        topic: template.topic,
        partition: sequence % 6,
        offset: 148_206 + sequence,
        timestamp: now,
        key: template.key,
        producer: template.producer,
        payload: template.payload,
        headers: [
          { key: "content-type", value: "application/json" },
          { key: "x-demo-stream", value: "true" },
        ],
        consumerGroups: [],
        status: "pending",
      };
      receiveEvent({ eventId: `${id}:produced`, type: "produced", message });

      if (sequence > 0 && sequence % 2 === 1) {
        const consumerGroup =
          DEMO_CONSUMER_GROUPS[sequence % DEMO_CONSUMER_GROUPS.length];
        receiveEvent({
          eventId: `demo-live-${sequence - 1}:consumed:${consumerGroup}`,
          type: "consumed",
          messageId: `demo-live-${sequence - 1}`,
          consumerGroup,
          memberId: `${consumerGroup}-1`,
          timestamp: now,
        });
      }
    }, 2_800);
    return () => window.clearInterval(timer);
  }, [demoMode, receiveEvent]);

  const topics = useMemo(
    () => Array.from(new Set(messages.map((message) => message.topic))).sort(),
    [messages],
  );
  const consumerGroups = useMemo(
    () =>
      Array.from(
        new Set(
          messages.flatMap((message) =>
            (message.consumerGroups ?? []).map((record) => record.groupId),
          ),
        ),
      ).sort(),
    [messages],
  );
  const consumedCount = useMemo(
    () => messages.filter((message) => messageStatus(message) === "consumed").length,
    [messages],
  );
  const pendingCount = messages.length - consumedCount;

  const search = query.trim().toLowerCase();
  const filteredMessages = useMemo(
    () => messages.filter((message) =>
      matchesMessageFilters(message, search, topicFilter, groupFilter, statusFilter),
    ),
    [messages, search, topicFilter, groupFilter, statusFilter],
  );
  const showArrivalPlaceholder = Boolean(
    activeArrival &&
      matchesMessageFilters(activeArrival.message, search, topicFilter, groupFilter, statusFilter),
  );

  const toggleLive = () => {
    const nextLive = !isLive;
    isLiveRef.current = nextLive;
    setIsLive(nextLive);
    onLiveChange?.(nextLive);
    if (nextLive && pendingEventsRef.current.length > 0) {
      const queued = pendingEventsRef.current.splice(0);
      setQueuedCount(0);
      queued.forEach(enqueueLiveEvent);
    }
    if (nextLive) processNextLiveEventRef.current();
  };

  const clearLogs = () => {
    setMessages([]);
    previousRowPositionsRef.current = null;
    if (arrivalTimerRef.current !== null) window.clearTimeout(arrivalTimerRef.current);
    if (nextArrivalTimerRef.current !== null) window.clearTimeout(nextArrivalTimerRef.current);
    arrivalTimerRef.current = null;
    nextArrivalTimerRef.current = null;
    activeArrivalRef.current = null;
    liveEventQueueRef.current = [];
    setActiveArrival(null);
    entranceTimersRef.current.forEach((timer) => window.clearTimeout(timer));
    entranceTimersRef.current.clear();
    setNewMessageIds(new Set());
    setExpandedIds(new Set());
    pendingEventsRef.current = [];
    setQueuedCount(0);
    onClear?.();
  };

  const clearFilters = () => {
    setQuery("");
    setTopicFilter(ALL_FILTER);
    setGroupFilter(ALL_FILTER);
    setStatusFilter("all");
  };

  const hasActiveFilters =
    query.length > 0 ||
    topicFilter !== ALL_FILTER ||
    groupFilter !== ALL_FILTER ||
    statusFilter !== "all";

  const toggleExpanded = (message: KafkaMessage) => {
    const wasExpanded = expandedIds.has(message.id);
    setExpandedIds((current) => {
      const next = new Set(current);
      if (next.has(message.id)) next.delete(message.id);
      else next.add(message.id);
      return next;
    });
    if (!wasExpanded) onMessageSelect?.(message);
  };

  return (
    <TooltipProvider delayDuration={200}>
      <section
        ref={rootRef}
        className={`kafka-log-panel ${className ?? ""}`}
        aria-labelledby="kafka-log-title"
      >
        <div className="kafka-panel-heading">
          <div className="min-w-0">
            <div className="kafka-eyebrow">
              <span className="kafka-eyebrow-dot" />
              STREAM EXPLORER
            </div>
            <h2 id="kafka-log-title" className="kafka-panel-title">
              Message log
            </h2>
            <p className="kafka-panel-description">
              Inspect produced messages and consumer group activity.
            </p>
          </div>
          <div className="kafka-stream-indicator" aria-live="polite">
            <span className={`kafka-stream-dot ${isLive ? "is-live" : "is-paused"}`} />
            <span>{isLive ? "Stream active" : "Stream paused"}</span>
          </div>
        </div>

        <div className="kafka-metrics" aria-label="Message stream summary">
          <Metric label="Messages" value={messages.length} icon={Layers3} tone="neutral" />
          <Metric label="Consumed" value={consumedCount} icon={Check} tone="green" />
          <Metric label="Awaiting" value={pendingCount} icon={Clock3} tone="amber" />
          <Metric label="Topics" value={topics.length} icon={Radio} tone="blue" />
        </div>

        <div className="kafka-toolbar" role="search" aria-label="Filter Kafka messages">
          <div className="kafka-search-wrap">
            <Search aria-hidden="true" className="kafka-search-icon size-4" />
            <Input
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search messages, keys, payloads…"
              aria-label="Search messages, keys, payloads"
              className="kafka-search-input"
            />
            {query && (
              <Button
                type="button"
                variant="ghost"
                size="icon-xs"
                aria-label="Clear search"
                className="kafka-search-clear"
                onClick={() => setQuery("")}
              >
                <X aria-hidden="true" />
              </Button>
            )}
          </div>

          <div className="kafka-filter-row">
            <div className="kafka-filter-label">
              <Filter aria-hidden="true" className="size-3.5" />
              <span>Filters</span>
            </div>
            <Select value={topicFilter} onValueChange={setTopicFilter}>
              <SelectTrigger className="kafka-filter-select" aria-label="Filter by topic">
                <SelectValue placeholder="All topics" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL_FILTER}>All topics</SelectItem>
                {topics.map((topic) => (
                  <SelectItem key={topic} value={topic}>
                    {topic}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={groupFilter} onValueChange={setGroupFilter}>
              <SelectTrigger
                className="kafka-filter-select kafka-group-select"
                aria-label="Filter by consumer group"
              >
                <SelectValue placeholder="All consumer groups" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL_FILTER}>All consumer groups</SelectItem>
                {consumerGroups.map((group) => (
                  <SelectItem key={group} value={group}>
                    {group}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select
              value={statusFilter}
              onValueChange={(value) => setStatusFilter(value as StatusFilter)}
            >
              <SelectTrigger className="kafka-filter-select kafka-status-select" aria-label="Filter by status">
                <SelectValue placeholder="Any status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Any status</SelectItem>
                <SelectItem value="consumed">Consumed</SelectItem>
                <SelectItem value="pending">Awaiting consumption</SelectItem>
              </SelectContent>
            </Select>
            {hasActiveFilters && (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={clearFilters}
                className="kafka-reset-button"
              >
                Reset
              </Button>
            )}
          </div>

          <Separator className="kafka-toolbar-divider" />

          <div className="kafka-actions">
            <Button
              type="button"
              variant="outline"
              size="sm"
              className={`kafka-live-button ${isLive ? "is-live" : "is-paused"}`}
              aria-pressed={isLive}
              onClick={toggleLive}
            >
              {isLive ? (
                <Pause aria-hidden="true" data-icon="inline-start" />
              ) : (
                <Play aria-hidden="true" data-icon="inline-start" />
              )}
              {isLive ? "Pause live" : "Resume live"}
              {!isLive && queuedCount > 0 && (
                <span className="kafka-queued-count">{queuedCount} queued</span>
              )}
            </Button>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  type="button"
                  variant="outline"
                  size="icon-sm"
                  className="kafka-icon-button"
                  onClick={clearLogs}
                  disabled={messages.length === 0 && queuedCount === 0 && !activeArrival}
                  aria-label="Clear message log"
                >
                  <Trash2 aria-hidden="true" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Clear visible log</TooltipContent>
            </Tooltip>
          </div>
        </div>

        <div className={`kafka-live-banner ${isLive ? "is-live" : "is-paused"}`}>
          <span className="kafka-live-banner-left">
            {isLive ? (
              <Waves aria-hidden="true" className="size-4" />
            ) : (
              <CircleDot aria-hidden="true" className="size-4" />
            )}
            <span>{isLive ? "Live mode" : "Updates paused"}</span>
          </span>
          <span className="kafka-live-banner-right">
            {isLive ? "Newest messages appear first" : `${queuedCount} buffered events`}
          </span>
        </div>

        <div className="kafka-table-frame">
          {filteredMessages.length > 0 || showArrivalPlaceholder ? (
            <ScrollArea className="kafka-table-scroll">
              <Table aria-label="Kafka message event log" className="kafka-table">
                <TableHeader>
                  <TableRow className="kafka-table-heading-row">
                    <TableHead className="kafka-time-col">Time</TableHead>
                    <TableHead className="kafka-status-col">Status</TableHead>
                    <TableHead>Topic</TableHead>
                    <TableHead className="kafka-position-col">Partition / offset</TableHead>
                    <TableHead className="kafka-group-col">Consumer groups</TableHead>
                    <TableHead className="kafka-key-col">Key / payload</TableHead>
                    <TableHead className="w-10"><span className="sr-only">Details</span></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {showArrivalPlaceholder && activeArrival && (
                    <ArrivalPlaceholder
                      key={activeArrival.eventId}
                      topic={activeArrival.message.topic}
                    />
                  )}
                  {filteredMessages.map((message) => {
                    const status = messageStatus(message);
                    const expanded = expandedIds.has(message.id);
                    const groups = message.consumerGroups ?? [];
                    const time = timeLabel(message.timestamp);
                    return (
                      <FragmentRows
                        key={message.id}
                        message={message}
                        status={status}
                        expanded={expanded}
                        groups={groups}
                        time={time}
                        isNewMessage={newMessageIds.has(message.id)}
                        onToggle={() => toggleExpanded(message)}
                      />
                    );
                  })}
                </TableBody>
              </Table>
              <ScrollBar orientation="horizontal" />
            </ScrollArea>
          ) : (
            <div className="kafka-empty-state">
              <span className="kafka-empty-icon"><Search aria-hidden="true" /></span>
              <h3>{messages.length === 0 ? "No messages yet" : "No matching messages"}</h3>
              <p>
                {messages.length === 0
                  ? "Newly produced Kafka messages will appear here."
                  : "Try changing your search or clearing one of the filters."}
              </p>
              {messages.length > 0 && hasActiveFilters && (
                <Button type="button" variant="outline" size="sm" onClick={clearFilters}>
                  Clear filters
                </Button>
              )}
            </div>
          )}
        </div>

        <div className="kafka-table-footer">
          <span>
            Showing <strong>{filteredMessages.length}</strong> of <strong>{messages.length}</strong> messages
          </span>
          <span className="kafka-footer-status">
            <span className={`kafka-stream-dot ${isLive ? "is-live" : "is-paused"}`} />
            {isLive ? "Listening for events" : "Listener paused"}
          </span>
        </div>
        <p className="sr-only" aria-live="polite" aria-atomic="true">
          {filteredMessages.length} Kafka messages shown. {consumedCount} consumed and {pendingCount} awaiting consumption.
        </p>
      </section>
    </TooltipProvider>
  );
}

function ArrivalPlaceholder({ topic }: { topic: string }) {
  return (
    <TableRow className="kafka-arrival-row" aria-label={`Reserving a row for ${topic}`}>
      <TableCell colSpan={7}>
        <div className="kafka-arrival-slot" role="status" aria-live="polite">
          <span className="kafka-arrival-pulse" aria-hidden="true" />
          <span>Reserving space for</span>
          <Badge variant="outline" className="kafka-arrival-topic">{topic}</Badge>
          <span className="kafka-arrival-shimmer" aria-hidden="true" />
        </div>
      </TableCell>
    </TableRow>
  );
}

function FragmentRows({
  message,
  status,
  expanded,
  groups,
  time,
  isNewMessage,
  onToggle,
}: {
  message: KafkaMessage;
  status: "consumed" | "pending";
  expanded: boolean;
  groups: NonNullable<KafkaMessage["consumerGroups"]>;
  time: { short: string; full: string };
  isNewMessage: boolean;
  onToggle: () => void;
}) {
  const groupLimit = 2;
  const shownGroups = groups.slice(0, groupLimit);
  const remainingGroups = groups.length - shownGroups.length;

  return (
    <>
      <TableRow
        data-kafka-message-id={message.id}
        className={`kafka-message-row ${expanded ? "is-expanded" : ""} ${isNewMessage ? "is-new" : ""}`}
      >
        <TableCell className="kafka-time-cell">
          <Tooltip>
            <TooltipTrigger asChild>
              <span className="kafka-time-stamp">{time.short}</span>
            </TooltipTrigger>
            <TooltipContent>{time.full}</TooltipContent>
          </Tooltip>
        </TableCell>
        <TableCell>
          <Badge
            variant="outline"
            className={`kafka-status-badge ${status === "consumed" ? "is-consumed" : "is-pending"}`}
          >
            <span className="kafka-status-indicator" />
            {status === "consumed" ? "Consumed" : "Awaiting"}
          </Badge>
        </TableCell>
        <TableCell>
          <span className="kafka-topic-name">{message.topic}</span>
        </TableCell>
        <TableCell>
          <span className="kafka-position">
            <span>p{message.partition}</span>
            <span className="kafka-position-separator">/</span>
            <span>{message.offset.toLocaleString()}</span>
          </span>
        </TableCell>
        <TableCell>
          {groups.length > 0 ? (
            <div className="kafka-groups-cell">
              {shownGroups.map((record) => (
                <Badge key={record.groupId} variant="secondary" className="kafka-group-badge">
                  <Users aria-hidden="true" />
                  {record.groupId}
                </Badge>
              ))}
              {remainingGroups > 0 && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span className="kafka-more-groups">+{remainingGroups}</span>
                  </TooltipTrigger>
                  <TooltipContent>
                    {groups.slice(groupLimit).map((record) => record.groupId).join(", ")}
                  </TooltipContent>
                </Tooltip>
              )}
            </div>
          ) : (
            <span className="kafka-muted-value">—</span>
          )}
        </TableCell>
        <TableCell className="kafka-payload-cell">
          <span className="kafka-message-key">{message.key ?? "<no key>"}</span>
          <span className="kafka-payload-preview">{preview(message.payload)}</span>
        </TableCell>
        <TableCell className="kafka-expand-cell">
          <Button
            type="button"
            variant="ghost"
            size="icon-xs"
            aria-label={`${expanded ? "Collapse" : "Expand"} details for ${message.topic} offset ${message.offset}`}
            aria-expanded={expanded}
            onClick={onToggle}
            className="kafka-expand-button"
          >
            {expanded ? <ChevronDown aria-hidden="true" /> : <ChevronRight aria-hidden="true" />}
          </Button>
        </TableCell>
      </TableRow>
      {expanded && (
        <TableRow className="kafka-details-row">
          <TableCell colSpan={7}>
            <div className="kafka-details-grid">
              <div className="kafka-details-meta">
                <div className="kafka-details-heading">
                  <ArrowDownToLine aria-hidden="true" className="size-4" />
                  <span>Message details</span>
                </div>
                <dl className="kafka-metadata-list">
                  <div><dt>Message ID</dt><dd>{message.id}</dd></div>
                  <div><dt>Topic</dt><dd>{message.topic}</dd></div>
                  <div><dt>Partition</dt><dd>{message.partition}</dd></div>
                  <div><dt>Offset</dt><dd>{message.offset.toLocaleString()}</dd></div>
                  <div><dt>Timestamp</dt><dd>{time.full}</dd></div>
                  <div><dt>Key</dt><dd>{message.key ?? "—"}</dd></div>
                  <div><dt>Producer</dt><dd>{message.producer ?? "—"}</dd></div>
                  <div><dt>Consumer groups</dt><dd>{groups.length ? groups.map((group) => group.groupId).join(", ") : "Not consumed"}</dd></div>
                </dl>
                {message.headers && message.headers.length > 0 && (
                  <div className="kafka-header-list">
                    <span className="kafka-detail-label">Headers</span>
                    {message.headers.map((header) => (
                      <span className="kafka-header-chip" key={`${header.key}:${header.value}`}>
                        <span>{header.key}</span><span>{header.value}</span>
                      </span>
                    ))}
                  </div>
                )}
              </div>
              <div className="kafka-payload-detail">
                <div className="kafka-details-heading">
                  <Activity aria-hidden="true" className="size-4" />
                  <span>Payload</span>
                </div>
                <ScrollArea className="kafka-json-scroll">
                  <pre className="kafka-json-block"><code>{serialize(message.payload)}</code></pre>
                  <ScrollBar orientation="horizontal" />
                </ScrollArea>
              </div>
            </div>
          </TableCell>
        </TableRow>
      )}
    </>
  );
}

export { KafkaLiveLogs, applyEvent };
export type { KafkaConsumedEvent, KafkaLiveLogsProps, KafkaLogEvent, KafkaMessage } from "./types";
