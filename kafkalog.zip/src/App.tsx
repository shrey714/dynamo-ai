import { Activity, ChevronRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { KafkaLiveLogs } from "@/components/kafka/KafkaLiveLogs";
import { DEMO_MESSAGES } from "@/components/kafka/sample-data";

function App() {
  return (
    <div className="kafka-app-shell">
      <div className="kafka-topbar">
        <div className="kafka-topbar-inner">
          <div className="kafka-brand-lockup">
            <span className="kafka-brand-mark"><Activity aria-hidden="true" /></span>
            <span className="kafka-brand-name">streamline</span>
            <Separator orientation="vertical" className="kafka-topbar-separator" />
            <nav aria-label="Breadcrumb" className="kafka-breadcrumbs">
              <span>Kafka</span>
              <ChevronRight aria-hidden="true" />
              <span>Observability</span>
            </nav>
          </div>
          <div className="kafka-topbar-actions">
            <Badge variant="outline" className="kafka-environment-badge">
              <span className="kafka-environment-dot" />
              Development
            </Badge>
            <span className="kafka-avatar" aria-label="Workspace owner">S</span>
          </div>
        </div>
      </div>

      <main className="kafka-main-content">
        <section className="kafka-page-heading" aria-labelledby="page-title">
          <div className="kafka-page-heading-main">
            <div className="kafka-breadcrumbs kafka-mobile-breadcrumbs">
              <span>Kafka</span><ChevronRight aria-hidden="true" /><span>Observability</span>
            </div>
            <div className="kafka-title-row">
              <div>
                <div className="kafka-page-kicker"><Activity aria-hidden="true" /> STREAMING / CLUSTER 01</div>
                <h1 id="page-title">Message logs</h1>
                <p>Follow messages from producer to consumer, as they happen.</p>
              </div>
            </div>
          </div>
          <div className="kafka-cluster-meta">
            <span className="kafka-cluster-label">SIMULATED CLUSTER</span>
            <span className="kafka-cluster-name"><span className="kafka-cluster-live-dot" /> demo-east-1</span>
          </div>
        </section>

        <KafkaLiveLogs
          initialMessages={DEMO_MESSAGES}
          demoMode
          maxMessages={250}
          className="kafka-live-logs-instance"
          onLiveChange={(isLive) => console.info(`Kafka stream ${isLive ? "resumed" : "paused"}`)}
          onClear={() => console.info("Kafka message log cleared")}
        />

        <footer className="kafka-page-footer">
          <span>Simulated stream · No broker connection</span>
          <span className="kafka-footer-right"><Activity aria-hidden="true" /> Component preview</span>
        </footer>
      </main>
    </div>
  );
}

export default App;
