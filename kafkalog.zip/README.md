# Kafka Live Logs

A frontend-only, reusable React component for inspecting Kafka producer and consumer activity. It is styled to echo the supplied Vercel Logs reference: dense rows, dark chrome, search and filters, a clear live/pause state, and expandable details. The preview uses generated sample events; there is no broker connection or backend.

## Component location

The reusable source lives in `src/components/kafka/`:

- `KafkaLiveLogs.tsx` — table, toolbar, filters, live controls, and event handling.
- `kafka-live-logs.css` — the new-message arrival animation, imported directly by the component.
- `types.ts` — typed message, consumer record, event, and callback contracts.
- `sample-data.ts` — demo rows and templates (optional when integrating).

It uses local shadcn/ui primitives in `src/components/ui/` and the `cn` helper in `src/lib/utils.ts`. Keep these if your target app does not already have the equivalent shadcn components.

## Install in this project

```bash
pnpm install
pnpm dev
```

The demo dashboard runs at the Vite preview. `demoMode` is enabled only by the example page in `src/App.tsx`; turn it off when connecting a real event source.

## Basic use

```tsx
import { KafkaLiveLogs } from "@/components/kafka/KafkaLiveLogs";
import type { KafkaLogEvent, KafkaMessage } from "@/components/kafka/types";

const initialMessages: KafkaMessage[] = [
  {
    id: "msg-1",
    topic: "orders.created",
    partition: 0,
    offset: 128,
    timestamp: new Date().toISOString(),
    key: "order-42",
    payload: { orderId: "order-42", total: 81.5 },
    producer: "checkout-api",
    consumerGroups: [],
    status: "pending",
  },
];

const incomingEvents: KafkaLogEvent[] = [
  {
    eventId: "evt-1",
    type: "consumed",
    messageId: "msg-1",
    consumerGroup: "billing-service",
    timestamp: new Date().toISOString(),
    memberId: "billing-2",
  },
];

<KafkaLiveLogs
  initialMessages={initialMessages}
  events={incomingEvents}
  demoMode={false}
  onLiveChange={(isLive) => console.log({ isLive })}
  onClear={() => console.log("log cleared")}
  onEventReceived={(event) => console.log(event)}
  onMessageSelect={(message) => console.log(message.id)}
/>;
```

New `produced` events are inserted at the top. A `consumed` event updates the matching message in place, adds or updates the consuming group, and changes its status. Consumed events can match by `messageId` or by the Kafka tuple `topic + partition + offset`. `eventId` values must be unique for deduplication. While paused, incoming events are buffered and applied in order when resumed. The component retains the newest 250 messages by default; override this with `maxMessages`.

For each visible produced event, the log first reserves one 48px row with a “Reserving space” indicator. Existing rows then move down into that space before the actual message replaces the placeholder and animates in. Arrivals are serialized to preserve event order; reduced-motion settings skip the staged movement.

## Moving to another app

1. Copy `src/components/kafka/` into the target application's source tree; this includes the component-local arrival-animation stylesheet.
2. Copy any missing shadcn primitives from `src/components/ui/`: `badge`, `button`, `input`, `scroll-area`, `separator`, `select`, `table`, and `tooltip`.
3. Copy `src/lib/utils.ts` if the application does not already provide the standard shadcn `cn` helper.
4. Ensure the app has the shadcn theme tokens and Tailwind CSS configuration used by those primitives. The example page shell is in `src/App.tsx`; the `kafka-*` component styling and theme tokens are in `src/index.css`, which you can copy or adapt to match your own app.
5. Install the dependencies that are not already present: `lucide-react`, `radix-ui`, `class-variance-authority`, `clsx`, and `tailwind-merge`.

The component has no server, database, environment variable, or Kafka client dependency. Its only external data boundary is the typed `initialMessages` / `events` props.
